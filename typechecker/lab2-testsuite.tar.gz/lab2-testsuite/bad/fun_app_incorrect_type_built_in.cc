int main() {
  printDouble(99);
  return 0;
}
