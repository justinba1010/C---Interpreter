int main () {
	int x0 = 0 ;
	if (false) 0;
	else bool x0 = true ;
	int x1 = x0 -- ;

	return 0;
}
