int main () {
  int x0 = 32 ;
  if (0 < 0 - 0) bool x0 = true ;
  else bool x0 = false ;
  printInt(x0);
  return 0 ;
}
