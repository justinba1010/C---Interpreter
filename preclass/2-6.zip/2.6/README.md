# Calculator in Haskell

## Build
`make`

## Run
`echo "3+3+5*11" | TestCalc`
