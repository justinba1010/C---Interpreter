package Calc;

import Calc.Absyn.*;

/** BNFC-Generated All Visitor */
public interface AllVisitor<R,A> extends
  Calc.Absyn.Exp.Visitor<R,A>
{}
