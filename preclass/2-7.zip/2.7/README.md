# Calc in Java

# Build
`make`

# Run
`echo "3+3*5" | java Calculator`
